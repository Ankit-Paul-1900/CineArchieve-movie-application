import React, { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
import './App.css';
// import Header from './components/Header'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import AppLayout from './components/AppLayout';
import { Suspense } from 'react';
import SearchMovie from './components/SearchMovie';
import Upcoming from './components/Upcoming';
import TopRated from './components/TopRated';
import About from './components/About';
import Login from './components/Login';
import LoginLayout from './components/LoginLayout';
function App() {
  // const [count, setCount] = useState(0)
  const Home = React.lazy(() => import('./components/Home/Home'));
const Popular = React.lazy(() => import('./components/Popular'));
const SingleMovie = React.lazy(() => import('./components/MovieComponents/SingleMovie'));
const FullMovieCast = React.lazy(() => import('./components/MovieComponents/FullMovieCast'));
  const [islogin,setIslogin]=useState<boolean>(false);
  const [username,setUsername]=useState<string>("");

  const LoggedIn=()=>{
    setIslogin(true);
  }

  const getUser=(user:any)=>{
     setUsername(user)
  }

  const LoggedOut=()=>{
    setIslogin(false);
  }
  return (
    <>
     {/* <Header/> */}
     {/* <Home/> */}
     <BrowserRouter>
     <Suspense fallback={<div>Loading...</div>}>
     <Routes>
        <Route path="/" element={<AppLayout LogOut={LoggedOut} login={islogin} username={username}/>}>
          <Route path="/" element={<Home/>} />
          <Route path="/movies" element={""}>
            <Route path="/movies/popular" element={<Popular/>} /> 
            <Route path="/movies/upcoming" element={<Upcoming/>} /> 
            <Route path="/movies/toprated" element={<TopRated/>} /> 
            <Route path="/movies/:id" element={<SingleMovie/>} /> 
            <Route path="/movies/:id/cast" element={<FullMovieCast/>} />
          </Route> 
          <Route path="/about" element={<About/>}/>
          <Route path="/search/:query" element={<SearchMovie/>}/>
          </Route>
        <Route path="/login" element={<LoginLayout/>}>
            <Route path="/login" element={<Login getuser={getUser} loginIn={LoggedIn} />}/>
          </Route>
     </Routes>
     </Suspense>
     </BrowserRouter>
    </>
  )
}

export default App
