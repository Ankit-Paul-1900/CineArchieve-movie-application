// Import React and necessary hooks
import React, { useEffect, useState, useRef } from 'react';
import './Login.css'; // Import the CSS file for styling
import Logo from './Logo';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
const Login:React.FC<any> = ({getuser, loginIn}) => {
    const [email, setEmail] = useState<any>('');
    const [password, setPassword] = useState<any>('');
    const [username, setUsername] = useState<any>('');
    const [userlist,setUserlist]=useState<any>([]);
    const [isCreated,setIsCreated]=useState<boolean>(false);
    const [isLogin,setIsLogin]=useState<boolean>(false);
    const textref=useRef<any>();
    const [isRegistered,setIsRegistered]=useState<boolean>(false);
    const navigate=useNavigate();
//Add data
useEffect(()=>{
    const data = {
        // Replace with your actual data object
        username: username,
        email: email,
        password:password
      };
      if(isRegistered){
      axios
        .post("https://api.sheetbest.com/sheets/175db7a2-41f4-4154-8f90-5ba1cd0a5312", data, {
          headers: {
            "Content-Type": "application/json",
          },
        })
        .then((response) => {
          console.log(response.data);
        })
        .catch((error) => {
          console.error("Error:", error);
        }).finally(()=>{
            setIsCreated(false);
            setIsRegistered(false);
        });
    }
 },[isRegistered])
 //search Data
    useEffect(()=>{
        if(isLogin){
            console.log("Hi");
            axios.get("https://api.sheetbest.com/sheets/175db7a2-41f4-4154-8f90-5ba1cd0a5312")
        .then((res) => {
    setUserlist(res.data);
    
  })
  .catch((error) => {
    console.error(error);
  });
        }
    },[isLogin])

    useEffect(()=>{
        
        const user=userlist?.find((item:any)=>{return( item.email==email && item.password==password)})?.username||"No data";
            if(isLogin){

                if(user =="No data"){
                console.log(user);

                   textref.current.innerHTML="Invalid email or password!!";
                    setIsLogin(false);
                }
                else{
                   
                    loginIn();
                    getuser(user);
                    setIsLogin(false);
                    navigate("/");

                }
            }
            },[userlist]
          );


    const handleSubmit = (e:any) => {
        e.preventDefault();
        console.log('Email:', email);
        console.log('Password:', password);
    };



  if(!isCreated){

  

    return (
        <>
        <div className="container">

        <div className="login-container">
            <Logo/>
            <form className="login-form" onSubmit={handleSubmit}>
                {/* <h2 className="login-title">Login</h2> */}
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"
                        required
                        />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter your password"
                        required
                        />
                        <label htmlFor="" ref={textref} style={{textAlign:"center"}}></label>
                </div>
                <button type="button" className="login-button" onClick={()=>{setIsLogin(true)}}>Login</button>

            </form>
                <label htmlFor="" className="register">Don't have Account?<span onClick={()=>setIsCreated(true)}>Register</span></label>
        </div>
    </div>
    </>
    )
}
else{

    return(
        <div className="container">
        
        <div className="login-container">
    <div className="logo-container">
        <Logo/>
    </div>
    <form className="login-form" onSubmit={handleSubmit}>
        {/* <h2 className="login-title">Register</h2> */}
        <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
                />
        </div>
        <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
                />
        </div>
        <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                />
        </div>
        <button type="button" className="login-button" onClick={()=>setIsRegistered((c)=>!c)}>Register</button>
    </form>
    <label htmlFor="" className="register"><span onClick={()=>setIsCreated(false)}>Go Back</span></label>

    </div>
</div>
)

    }
};

export default Login;
