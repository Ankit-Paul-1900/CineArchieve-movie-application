import {  NavLink } from "react-router-dom";
import { IoMdSearch } from "react-icons/io";
import { IoMdMenu, IoMdClose } from "react-icons/io";
import "./Header.css";
import { useRef, useState } from "react";
import Logo from "./Logo";
const Header:React.FC<any> =({logout,logvalue,user})=>{
    const searchref=useRef<any>("");
    const [query,setQuery]=useState<string>("");
    const [hamClose,setHamClose]=useState<boolean>(false);
    const newQuery=()=>{
        setQuery(searchref.current.value)
    }
    const toggleMenu=()=>{
        setHamClose(!hamClose);
    }
    const handleClick = (e:any) => {
        e.preventDefault(); // Prevent navigation
        console.log("NavLink clicked, but no navigation!");
      };
    return(
        <>
        <div className="navbar">
            
            <Logo/>
            <div className="search_bar">
                <input type="text" placeholder="Search Movie Name" ref={searchref} onKeyUp={newQuery}  />
                <span className="search-cont">
                    <NavLink to={"/search/"+query}>
                    <IoMdSearch  className="searchicon" />
                    </NavLink>
                    </span>
            </div>
            <button className="hamburger" onClick={toggleMenu} >
                {!hamClose? <IoMdMenu/>:<IoMdClose/>}
            </button>
            <div className={`options ${hamClose ? "show" : ""}`}>
                <ul>

                    <li className="link">
                    <NavLink   to="/"  className={({ isActive, isPending }) =>
    isPending ? "pending" : isActive ? "active" : "notactive" 
  } onClick={toggleMenu}>Home</NavLink>
                    </li>
                    <li className="dropdown">
                <NavLink to="/movies"  className={({ isActive, isPending }) =>
    isPending ? "pending" : isActive ? "active" : "notactive"
            } onClick={handleClick}>Movies
      </NavLink>

                        {/* <label htmlFor="" >Movies</label> */}
                        <div className="dropdown-content">
                            <NavLink className="link upperborder" to="/movies/popular" onClick={toggleMenu}>Popular</NavLink>
                            <NavLink className="link" to="/movies/toprated" onClick={toggleMenu}>Top Rated</NavLink>
                            <NavLink className="link lowerborder" to="/movies/upcoming" onClick={toggleMenu}>Upcoming</NavLink>
         
                        </div>
                    </li>
                    
                    <li>
                        
                    <NavLink to="/about"  className={({ isActive, isPending }) =>
                      isPending ? "pending" : isActive ? "active" : "notactive"
                    } onClick={toggleMenu}>
                        About
                    </NavLink>
                        </li>
                    <li style={{display:"flex", justifyContent:"center"}}> { !logvalue?
                        <NavLink to="/login">
                        <button>
                            Login
                            </button>
                        </NavLink>
                        :(
                            <>
                            <span className="user">{user?.substring(0,2)}</span>
                            <button onClick={logout}>LogOut</button> 
                            </>
                        )
                        }
                     </li>
                </ul>
            </div>
        </div>
        </>
    )
}
export default Header;



// <!DOCTYPE html>
// <html lang="en">
// <head>
//   <meta charset="UTF-8">
//   <meta name="viewport" content="width=device-width, initial-scale=1.0">
//   <title>Navbar with Suboptions</title>
//   <style>
//     body {
//       font-family: Arial, sans-serif;
//       margin: 0;
//       padding: 0;
//     }
//     .navbar {
//       display: flex;
//       background-color: #333;
//       padding: 10px;
//     }
//     .navbar a {
//       color: white;
//       text-decoration: none;
//       padding: 10px 15px;
//       display: block;
//     }
//     .navbar > .dropdown {
//       position: relative;
//     }
//     .navbar a:hover {
//       background-color: #575757;
//     }
//     .dropdown-content {
//       display: none;
//       position: absolute;
//       background-color: #444;
//       min-width: 150px;
//       box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
//       z-index: 1;
//     }
//     .dropdown-content a {
//       color: white;
//       padding: 10px 15px;
//       text-decoration: none;
//       display: block;
//     }
//     .dropdown-content a:hover {
//       background-color: #575757;
//     }
//     .dropdown:hover .dropdown-content {
//       display: block;
//     }
//   </style>
// </head>
// <body>
//   <div class="navbar">
//     <a href="#home">Home</a>
//     <a href="#services">Services</a>
//     <div class="dropdown">
//       <a href="#about">About</a>
//       <div class="dropdown-content">
//         <a href="#team">Our Team</a>
//         <a href="#history">History</a>
//         <a href="#mission">Mission</a>
//       </div>
//     </div>
//     <a href="#contact">Contact</a>
//   </div>
// </body>
// </html>
