import "./Logo.css";
const Logo=()=>{
    return(
        <>
             <div className="logo">
                <div className="play-button"></div>
                <div className="logo-text">
                         <span>Cine</span>Archive
                </div>
            </div>
        </>
    )
}
export default Logo;