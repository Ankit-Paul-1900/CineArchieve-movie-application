import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";

const AppLayout:React.FC<any>=({LogOut, login,username})=>{
    return(
        <>
        <div>
       <Header logout={LogOut} logvalue={login} user={username}/>
        <Outlet/>
        <Footer/>
        </div>
        </>
    )
}
export default AppLayout;