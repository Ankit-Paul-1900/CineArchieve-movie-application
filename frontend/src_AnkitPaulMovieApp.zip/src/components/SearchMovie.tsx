import { useEffect, useState } from "react";
import { NavLink, useParams } from "react-router-dom";
import "./SearchMovie.css";
import axios from "axios";
const SearchMovie=()=>{
  const searchquery=useParams();
    const [searchmovie,setSearchmovie]=useState<any>([]);
    const [isLoading,setIsLoading]=useState<boolean>(false);
  const imageURL='https://image.tmdb.org/t/p/w500';

    useEffect(()=>{
      
      setIsLoading(true)

const options = {
  method: 'GET',
  url: 'https://api.themoviedb.org/3/search/movie',
  params: {query: `${searchquery.query}`, include_adult: 'false', language: 'en-US', page: '1'},
  headers: {
    accept: 'application/json',
    Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwNDhkYWIyMjI4NjRhMTEyZjRlOWYzNDJlZGVkODhkYiIsIm5iZiI6MTczNDc1MzM2OS4zMTYsInN1YiI6IjY3NjYzYzU5YjY3ZTQ1NDcyNTVlMGUwMSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.jftBC5O2Hmp4oq-h5CYCei8mkzRLhfNwi4EwwOfXnaE'
  }
};

axios
  .request(options)
  .then(res =>{
        setSearchmovie(res.data.results);
     setIsLoading(false)
        
      })
        .catch(err => console.error(err))
        .finally(() => {
          setIsLoading(false)
        });
    },[searchquery.query]);

    if(!isLoading){
    return(
        <>
        <div className="main-container">
           <h2>Search Results..</h2>
            {
                searchmovie.map((item:any)=>{
                    return(
                            <>
                              
                               <div className="moviecard" key={item.id}>
                                    <img src={imageURL+item.poster_path} alt="" height={300} />
                                    <NavLink
                                    to={"/movies/"+item.id} className="Link">
                                    <div className="movie-text">
                                    <label >{item.original_title}</label>
                                    <p>{item.release_date?.split("-")[0]||"Date Not Found"}</p>
                                    <p>{item.overview}</p>
                                    </div>
                                    </NavLink>    

                                </div>
                            </>
                    )
                })
            }
          
        </div>        
        </>
     )
    }
    else{
      return(
        <>
          <div className="loading">
            Loading......
          </div>
        </>
      )
    }
}
export default SearchMovie;